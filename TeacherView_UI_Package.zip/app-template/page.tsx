'use client';

import React, { useState } from 'react';
import { TeacherView } from '../components/TeacherView';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { OnePageParentReport } from '../components/OnePageParentReport';
import { INITIAL_STUDENTS } from '../data/sample-seed';
import { INITIAL_ALUMNI_RECORDS } from '../data/alumni-data';
import { StudentMaster, UserRole, AlumniRecord } from '../types';

export default function TeacherViewDemoPage() {
  const [currentTab, setCurrentTab] = useState<string>('teacher-view');
  const [selectedStudentKey, setSelectedStudentKey] = useState<string>('hose');
  const [isPrivacyMode, setIsPrivacyMode] = useState<boolean>(false);
  const [currentRole, setCurrentRole] = useState<UserRole>('counselor');
  const [students, setStudents] = useState<Record<string, StudentMaster>>(INITIAL_STUDENTS);
  const [alumniList, setAlumniList] = useState<AlumniRecord[]>(INITIAL_ALUMNI_RECORDS);

  const activeStudent = students[selectedStudentKey] || students.hose;

  const handleTogglePrivacyMode = () => {
    setIsPrivacyMode((prev) => !prev);
  };

  const handleSwitchStudent = (key: string) => {
    setSelectedStudentKey(key);
  };

  const handleSaveStudent = (updatedStudent: StudentMaster) => {
    setStudents((prev) => ({
      ...prev,
      [selectedStudentKey]: updatedStudent,
    }));
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Top Header */}
      <Header
        onSelectTab={setCurrentTab}
        selectedStudentKey={selectedStudentKey}
        onSelectStudent={handleSwitchStudent}
        isPrivacyMode={isPrivacyMode}
        onTogglePrivacyMode={handleTogglePrivacyMode}
        currentRole={currentRole}
        authenticatedUserName="Danny Pyung (담임교사)"
        onOpenAdminAccess={() => {}}
        onExitAdminMode={() => {}}
      />

      {/* Left Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        targetStudent={activeStudent}
        currentRole={currentRole}
        onOpenAdminAccess={() => {}}
        onExitAdminMode={() => {}}
      />

      {/* Main Content */}
      <div className="pl-64">
        <main className="w-full pt-20 px-gutter-desktop pb-space-xl min-h-screen">
          {currentTab === 'teacher-view' && (
            <TeacherView
              student={activeStudent}
              allStudents={students}
              activeStudentKey={selectedStudentKey}
              onSelectStudentKey={handleSwitchStudent}
              isPrivacyMode={isPrivacyMode}
              onTogglePrivacyMode={handleTogglePrivacyMode}
              onNavigateToPrint={() => setCurrentTab('print-report')}
              onUpdateStudent={handleSaveStudent}
              alumniList={alumniList}
            />
          )}

          {currentTab === 'print-report' && (
            <OnePageParentReport
              student={activeStudent}
              activeKey={selectedStudentKey}
              onSwitchStudent={handleSwitchStudent}
              allStudents={students}
            />
          )}
        </main>
      </div>
    </div>
  );
}
