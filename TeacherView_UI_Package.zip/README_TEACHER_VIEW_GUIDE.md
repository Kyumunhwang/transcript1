# LIS 등대국제학교 교사용 뷰 (Teacher View) UI 컴포넌트 & 스타일 독립 패키지

본 패키지는 **교사용 뷰 화면(TeacherView)**의 모든 UI/UX, 디자인 시스템 토큰(Tailwind CSS), 1~12학년 재학생 및 졸업생 데이터, 시뮬레이터, 1:1 상담 기록부를 **다른 프로젝트 또는 다른 컴퓨터의 Antigravity 환경**에서 100% 동일하게 개발하고 재사용할 수 있도록 완결된 형태로 패키징한 자료입니다.

---

## 📦 패키지 디렉토리 구조

```text
TeacherView_Package/
├── components/                     # 핵심 UI 컴포넌트
│   ├── TeacherView.tsx             # [핵심] 교사용 뷰 화면 (재학생/졸업생 탭, 학년별 필터, 공인시험, 비교과, 지원목표대학 등)
│   ├── CounselingLogbook.tsx       # 1:1 진로·진학 상담 기록부 (다수 교사 누적 기록, 학기/년도 필터)
│   ├── GpaSimulator.tsx            # 등대 자체 가상 GPA 시뮬레이터 엔진
│   ├── OnePageParentReport.tsx     # A4 인쇄용 공식 상담 종합 리포트 뷰
│   ├── Header.tsx                  # 상단 네비게이션 & 재학생/졸업생 스위처
│   ├── Sidebar.tsx                 # 고정 사이드바 메뉴
│   └── AlumniManager.tsx           # 졸업생 관리 연동 컴포넌트
├── types/                          # TypeScript 인터페이스 & 데이터 모델
│   └── index.ts                    # StudentMaster, TranscriptCourse, CounselingLogEntry, AlumniRecord 등
├── data/                           # 실데이터 및 시드 데이터
│   ├── sample-seed.ts              # G1~G12 재학생(고호세, 김서준, 이지우, 김민재 등) & 졸업생(황준영) 풀 데이터
│   ├── alumni-data.ts              # 졸업생 진학 아카이브 (NYU, UC 버클리, 조지아텍 등 합격 내역)
│   ├── user-accounts.ts            # 교사/학생/학부모 RBAC 계정 모델
│   └── gradelink-extracted-students.json # Gradelink 공식 성적표 실데이터 (16개 학기/9개 학기)
├── lib/                            # 비즈니스 로직 & 계산 엔진
│   ├── lighthouse-parser.ts        # 등대 GPA 산출식 및 AP(+1.0)/Honors(+0.5) 가산점 계산
│   ├── gradelink-csv-parser.ts     # Gradelink 공식 성적 CSV 파서
│   └── utils.ts
├── styles/                         # 디자인 시스템 & 스타일 토큰
│   ├── tailwind.config.ts          # Material 3 기반 정밀 컬러 토큰, Spacing, Font 설정
│   ├── globals.css                 # A4 프린트 레이아웃 규칙 및 기본 레이어
│   └── postcss.config.js
├── app-template/                   # 즉시 실행 가능한 Next.js 페이지 템플릿
│   ├── page.tsx                    # 교사용 뷰를 바로 띄우는 데모 엔트리포인트
│   ├── layout.tsx
│   └── globals.css
├── public/
│   └── logo.png                    # LIS 등대국제학교 로고
├── package.json                    # 필요한 의존성 라이브러리 목록 (Next.js, Lucide, Tailwind 등)
└── tsconfig.json                   # Path Alias (@/*) 설정
```

---

## 🚀 다른 프로젝트 / 다른 컴퓨터 Antigravity에서 사용하는 방법

### 방법 A: 기존 Next.js 14 프로젝트에 부품(컴포넌트)으로 이식하기

1. **디렉토리 복사**:
   - `components/` ➔ 대상 프로젝트의 `src/components/counseling/`
   - `types/` ➔ 대상 프로젝트의 `src/types/`
   - `data/` ➔ 대상 프로젝트의 `src/data/`
   - `lib/` ➔ 대상 프로젝트의 `src/lib/`
   - `public/logo.png` ➔ 대상 프로젝트의 `public/`

2. **Tailwind CSS 색상 토큰 복사**:
   - 본 패키지의 `styles/tailwind.config.ts`에 정의된 `colors` 객체(`primary`, `primary-container`, `secondary`, `surface`, `on-surface` 등)와 `spacing`을 대상 프로젝트의 `tailwind.config.ts`의 `theme.extend`에 그대로 붙여넣습니다.
   - `styles/globals.css`의 `@media print` 스타일을 대상 프로젝트의 `globals.css`에 추가합니다.

3. **필수 패키지 설치**:
   ```bash
   npm install lucide-react clsx tailwind-merge unpdf
   ```

4. **컴포넌트 호출**:
   ```tsx
   import { TeacherView } from '@/components/counseling/TeacherView';
   import { INITIAL_STUDENTS } from '@/data/sample-seed';
   import { INITIAL_ALUMNI_RECORDS } from '@/data/alumni-data';

   export default function MyTeacherPage() {
     const [students, setStudents] = useState(INITIAL_STUDENTS);
     const [activeKey, setActiveKey] = useState('hose');

     return (
       <TeacherView
         student={students[activeKey]}
         allStudents={students}
         activeStudentKey={activeKey}
         onSelectStudentKey={setActiveKey}
         isPrivacyMode={false}
         onTogglePrivacyMode={() => {}}
         onNavigateToPrint={() => {}}
         onUpdateStudent={(updated) => setStudents(prev => ({ ...prev, [activeKey]: updated }))}
         alumniList={INITIAL_ALUMNI_RECORDS}
       />
     );
   }
   ```

---

### 방법 B: 새 프로젝트로 즉시 단독 실행하기

1. 압축 해제한 폴더(`TeacherView_Package`)로 이동합니다.
2. 터미널에서 의존성을 설치합니다:
   ```bash
   npm install
   ```
3. `app-template` 폴더를 `src/app`으로 이동하거나 복사합니다:
   ```bash
   mkdir -p src
   cp -r components types data lib src/
   cp -r app-template src/app
   cp styles/tailwind.config.ts ./
   ```
4. 개발 서버 실행:
   ```bash
   npm run dev:counseling-app
   ```
5. 브라우저에서 `http://localhost:3043` 접속 시 바로 교사용 뷰 화면이 가동됩니다.

---

## 🎨 교사용 뷰 핵심 기능 요약

- **현재 재학생 (Current Students) vs 졸업생 (Alumni) 분리**: 상단 탭 하나로 재학생 모드와 졸업생 아카이브를 즉시 전환.
- **학년(Grade 1~12) 및 반(Class)별 학생 명단 필터링**: G12, G11, G10, G9, G7, G3 등 학년 선택 시 해당 학년 학생만 드롭다운 및 퀵 칩스로 선택.
- **3대 핵심 진학 영역 패널**:
  1. 공인시험 성적 (SAT, TOEFL, AP 과목별 점수)
  2. 비교과 활동 및 봉사/리더십 시수 통계
  3. 지원 목표 대학군 (Target Tier Readiness)
- **1:1 진로·진학 상담 기록부 연동**: 상담 날짜, 상담 교사, 상담 내용, 학업/비교과 조언, 교사 대외비 메모 누적 관리.
- **A4 상담 리포트 1초 인쇄 연동**: CSS `@media print` 기반으로 A4 규격에 정확히 맞춘 학부모 상담용 리포트 인쇄 지원.
